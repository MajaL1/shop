//  Add ui-router as a dependency
angular.module('app', ['ui.router']);