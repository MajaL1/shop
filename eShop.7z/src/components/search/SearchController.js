angular.module('app').controller('SearchController', function($scope){

	$scope.example = 'Example from SearchController';

});