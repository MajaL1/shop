angular.module('app').controller('ExampleController', function($scope){

	$scope.example = 'Example from ExampleController';

});