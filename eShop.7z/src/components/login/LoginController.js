angular.module('app').controller('LoginController', function($scope){

	$scope.example = 'Example from LoginController';

});