angular.module('app').controller('HomeController', function($scope){

	$scope.example = 'Example from HomeController';

});